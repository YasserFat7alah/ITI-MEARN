import Header from './components/Header';
import Footer from './components/Footer/Footer';
import logo from './assets/react.svg'


function App(){
    const name = 'Ahmed';

    const alertUser = (username) => {
        alert(username)
    }


    const handleChange = (e) => {
      console.log(e.target.value)
    }

    return(
        <div>
            <Header />
            <h2 className="text-grey">App component</h2>
            <p style={{
                color: 'white',
                backgroundColor : 'grey',
                fontSize: '18px'
            }}>App content will appear here</p>
            <p>Here's another content</p>
            <h4>Hello , {name}</h4>
            <button onClick={() => alertUser('Ahmed')}>Click me</button>
            <button onClick={() => alertUser('Nada')}>Click me</button>
            <button onClick={() => alertUser('Omnia')}>Click me</button>

            {/* <button onClick={alertUser}>Click me</button> */}

            <input onChange={handleChange} />
            <img src={logo}/>
            <br />
            <hr />
            <Footer />
        </div>
    )
}

export default App;

// Component name => Capital letter
// JSX => return one parent wrapper element
// CLOSING TAGS
// camelCase => class=> className 
// style STRING XXX => style object { key : value }