
const Header = () => {
  return (
    <>
      <h4>Header component</h4>
      <p>Header content goes here</p>
    </>
  );
};

export default Header;
