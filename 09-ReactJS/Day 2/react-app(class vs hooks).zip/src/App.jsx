import Header from "./components/Header";
import Footer from "./components/Footer/Footer";
import AdminsC from "./components/AdminsC";
import AdminsF from "./components/AdminsF";

function App() {
  return (
    <div className="container my-5">
      <Header />
      <hr />
      <AdminsC />
      <hr />
      <AdminsF />
      <hr />
      <Footer />
    </div>
  );
}

export default App;

// Component name => Capital letter
// JSX => return one parent wrapper element
// CLOSING TAGS
// camelCase => class=> className
// style STRING XXX => style object { key : value }
