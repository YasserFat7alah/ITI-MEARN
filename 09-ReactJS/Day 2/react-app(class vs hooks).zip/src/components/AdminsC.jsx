import React from 'react';

class AdminsC extends React.Component {
    constructor() {
        super();
        this.state = {
            name: 'Ahmed',
            age: 24,
            education: 'computer science'
        }
    }

    componentDidMount(){
        // Only once on load
        // API calls
    }

    componentDidUpdate(){
        // Listen on changes
    }

    componentWillUnmount(){
        // Destroy => clean up method
        // Clear interval
    }

    handleNameChange = (newName) => {
        //    this.state.name = newName;XXXXXX
        this.setState({
            name: newName
        })
    }

    render() {
        return (
            <>
                <h3>Hello Class Component</h3>
                <p>Hi , {this.state.name} has {this.state.age} and graduated from {this.state.education}</p>
                <button className='btn btn-primary' onClick={() => this.handleNameChange('Omar')}>Change name to Omar</button>
            </>
        )
    }
}

export default AdminsC;

