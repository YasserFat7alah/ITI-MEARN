import { useEffect, useState } from "react";

const AdminsF = () => {
  // Getter key , setter Method
  const [adminUser, setAdminUser] = useState({
    name: "Ahmed",
    age: 24,
    education: "compunter science",
  });

  const [isAdmin, setIsAdmin] = useState();
  const [username, setUsername] = useState("Nada");

  useEffect(() => {
    // componentDidMount => fire only once on load
    return () => {
      // componentWillUnmout
      // Destroy
    };
  }, []);

  useEffect(() => {
    // componentDidUpdate
    //  load , changes adminUser
  }, [adminUser]);

  useEffect(() => {
    // componentDidUpdate
    //  load , changes adminUser
  }, [username]);

  const handeUsernameChange = (newName) => {
    setAdminUser({
      ...adminUser,
      name: newName,
    });
  };

  return (
    <>
      <h3>Hello Functional Component</h3>
      <p>
        Hi, {adminUser.name} has {adminUser.age} and graduated from{" "}
        {adminUser.education}
      </p>
      <button
        className="btn btn-primary"
        onClick={() => handeUsernameChange("Omar")}
      >
        Change username to Omar
      </button>
    </>
  );
};

export default AdminsF;
