import './Footer.css';

const Footer = () => {
    return(
        <>
          <h4>Footer component</h4>
          <p className='paragraph-footer'>Test footer</p>
        </>
    )
}

export default Footer;