import RecipesList from './components/RecipesList'
import './App.css'

function App() {
  return (
    <div className='container my-5'>
     <RecipesList />
    </div>
  )
}

export default App
