const RecipeCard = (props) => {
  console.log(props);
  const { recipe, handleDelete } = props;
  return (
    <div className="card h-100">
      <img src={recipe.image} className="card-img-top" alt={recipe.name} />
      <div className="card-body">
        {/* {recipe.cookTimeMinutes <= 10 ? (
                    <span className="badge text-bg-success">Easy to cook</span>
                  ) : (
                    <span className="badge text-bg-warning">Need more time</span>
                  )} */}
        {recipe.cookTimeMinutes <= 10 && (
          <span className="badge text-bg-success">Easy to cook</span>
        )}
        <h5 className="card-title">{recipe.name}</h5>
        <p className="card-text">
          This is a wider card with supporting text below as a natural lead-in
          to additional content. This content is a little bit longer.
        </p>
      </div>
      <div className="card-footer">
        <button
          className="btn btn-danger"
          onClick={() => handleDelete(recipe.id)}
        >
          Delete
        </button>
      </div>
      <Child recipe={recipe}/>
    </div>
  );
};

export default RecipeCard;
