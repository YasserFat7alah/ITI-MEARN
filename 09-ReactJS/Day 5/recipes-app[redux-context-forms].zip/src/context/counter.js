import { createContext } from "react";

const CounterContext = createContext();

export default CounterContext;