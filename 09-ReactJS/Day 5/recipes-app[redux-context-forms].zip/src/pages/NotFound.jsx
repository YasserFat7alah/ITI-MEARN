export default function NotFound() {
  return (
    <div className='text-center my-5'>
        <h3>404 - Not found page</h3>
    </div>
  )
}
