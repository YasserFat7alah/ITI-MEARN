
export default function Settings() {
  return (
    <div>Settings</div>
  )
}
